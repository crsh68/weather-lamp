---
name: Bug Report
about: Report a bug or issue with Weather Lamp
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
<!-- A clear and concise description of the bug -->

## Expected Behavior
<!-- What you expected to happen -->

## Actual Behavior
<!-- What actually happened -->

## Steps to Reproduce
1. 
2. 
3. 

## Hardware Information
- **ESP32 Board Model**: (e.g., ESP32-WROOM-32)
- **LED Count**: 
- **LED Type**: (e.g., WS2812B)
- **Power Supply**: (e.g., 5V 2A)

## Software Information
- **Arduino IDE Version**: 
- **ESP32 Board Package Version**: 
- **Library Versions**:
  - FastLED: 
  - HomeSpan: 
  - ArduinoJson: 

## Configuration
- **WiFi Network**: 2.4GHz or 5GHz?
- **City/Location**: 
- **Weather API**: OpenWeatherMap (default) or custom?

## Serial Monitor Output
<!-- Paste relevant Serial Monitor output here (115200 baud) -->
```
[Paste here]
```

## Additional Context
<!-- Add any other context, screenshots, or information -->

## Checklist
- [ ] I've checked existing issues
- [ ] Serial Monitor shows relevant error messages
- [ ] WiFi credentials are correct
- [ ] API key is valid and activated
- [ ] Common ground between ESP32 and power supply
- [ ] LED strip is receiving power
