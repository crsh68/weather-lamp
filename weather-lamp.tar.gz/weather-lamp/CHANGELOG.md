# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Web configuration portal
- Multiple city support
- Weather forecast display
- Custom color schemes
- MQTT integration
- Power consumption optimization

## [1.0.0] - 2025-02-16

### Added
- Initial release
- ESP32 support with WS2812B LED strips
- 8 weather effects:
  - Sunny (sunrise/sunset gradient)
  - Cloudy (grey clouds)
  - Rain (blue raindrops)
  - Thunder (lightning flashes)
  - Snow (white snowflakes)
  - Fog (misty gradient)
  - Wind (fast streaks)
  - Amber alert (solid amber)
- OpenWeatherMap API integration
- Automatic weather updates every 10 minutes
- Apple HomeKit integration via HomeSpan
- Physical button control (power toggle)
- HomeKit controls:
  - Power on/off
  - Brightness adjustment (0-100%)
- WiFi watchdog with auto-reconnect
- Serial debug output
- Comprehensive documentation
- MIT License

### Features
- Real-time weather data fetching
- Smooth LED animations
- HomeKit automation support
- Stable WiFi connection management
- Low memory footprint
- Easy hardware setup

---

## Version History

- **1.0.0** - Initial public release (2025-02-16)

## Upgrade Notes

### To 1.0.0
- First release - no upgrade needed
- Flash firmware using Arduino IDE
- Configure WiFi and API credentials in code
- Pair with HomeKit using setup code

---

For more details, see the [commit history](https://github.com/yourusername/weather-lamp/commits/main).
