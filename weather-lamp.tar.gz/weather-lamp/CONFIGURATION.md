# Configuration Guide

This guide helps you configure the Weather Lamp before first use.

## Required Configurations

### 1. WiFi Credentials

Open `WeatherLamp.ino` and find these lines (around line 26):

```cpp
const char* ssid     = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
```

Replace with your actual WiFi network credentials:

```cpp
const char* ssid     = "MyHomeNetwork";
const char* password = "MySecurePassword123";
```

**Important Notes:**
- ESP32 only supports **2.4GHz WiFi** (not 5GHz)
- Use exact SSID (case-sensitive)
- Special characters in password are supported
- Avoid WiFi networks with captive portals (hotel/public WiFi)

---

### 2. OpenWeatherMap API Key

#### Get Your Free API Key:

1. Go to [OpenWeatherMap](https://openweathermap.org/api)
2. Click "Sign Up" (or "Sign In" if you have an account)
3. Verify your email address
4. Go to your [API Keys page](https://home.openweathermap.org/api_keys)
5. Copy your default API key (or create a new one)

#### Add to Code:

Find this line in `WeatherLamp.ino` (around line 29):

```cpp
String apiKey = "YOUR_OPENWEATHERMAP_API_KEY";
```

Replace with your actual API key:

```cpp
String apiKey = "abc123def456your789api012key345here";
```

**API Key Notes:**
- Free tier: 60 calls/minute, 1,000,000/month (plenty for this project)
- New keys may take up to 2 hours to activate
- Keep your API key private (don't share publicly)
- Rate limit: Weather updates every 10 minutes = ~4,320 calls/month

---

### 3. City/Location

Find this line (around line 30):

```cpp
String city   = "YOUR_CITY";
```

Replace with your city name:

```cpp
String city   = "London";
// or
String city   = "New York";
// or
String city   = "Tokyo";
```

**City Name Tips:**
- Use city name only: `"Paris"` not `"Paris, France"`
- For US cities, add state: `"Portland,OR"` vs `"Portland,ME"`
- Use English name: `"Munich"` not `"München"`
- Check spelling at [OpenWeatherMap City List](https://openweathermap.org/find)

---

## Optional Configurations

### LED Settings

If using a different LED count or type:

```cpp
#define LED_PIN     5        // GPIO pin for LED data
#define LED_COUNT   24       // Number of LEDs in your strip
#define LED_TYPE    WS2812B  // LED chipset (WS2812B, WS2811, etc.)
#define COLOR_ORDER GRB      // Color order (RGB, GRB, BRG, etc.)
```

Common configurations:
- **24 LEDs**: Small lamp, ring, or strip
- **50 LEDs**: Medium strip
- **100 LEDs**: Large installation

**Important**: Higher LED counts require more power!

---

### Button Pin

If using a different GPIO pin for the button:

```cpp
#define BUTTON_PIN  15   // Default: GPIO 15
```

---

### Weather Update Interval

Change how often weather data is fetched:

```cpp
const unsigned long WEATHER_INTERVAL = 600000;  // 10 minutes (in milliseconds)
```

Common intervals:
- `300000` = 5 minutes
- `600000` = 10 minutes (default, recommended)
- `900000` = 15 minutes
- `1800000` = 30 minutes

**Note**: More frequent updates consume more API calls.

---

### Brightness

Default brightness level (0-100):

```cpp
int brightness = 20;  // Default: 20% brightness
```

Adjust to your preference:
- `10` = Very dim (night mode)
- `20` = Low (default)
- `50` = Medium
- `100` = Maximum (bright!)

**Note**: Higher brightness = more power consumption and heat.

---

## HomeKit Configuration

### Default Setup Code

The HomeKit setup code is defined in the `setup()` function:

```cpp
homeSpan.begin(Category::Lighting, "Weather Lamp");
homeSpan.setPairingCode("46637726");
```

**Default Pairing Code**: `466-37-726`

### Changing Setup Code (Optional)

You can customize the 8-digit code:

```cpp
homeSpan.setPairingCode("12345678");  // Your custom code
```

Format: 8 digits (displayed as XXX-XX-XXX in Home app)

---

## Configuration Checklist

Before uploading the code, verify:

- [ ] WiFi SSID is correct
- [ ] WiFi password is correct (case-sensitive)
- [ ] API key is valid and active
- [ ] City name is correct
- [ ] LED_COUNT matches your strip
- [ ] LED_PIN is correct for your wiring
- [ ] Button pin matches your hardware

---

## Validation

### Test WiFi Connection

1. Upload code to ESP32
2. Open Serial Monitor (115200 baud)
3. Look for:
   ```
   Connecting to WiFi...
   WiFi connected
   IP address: 192.168.1.xxx
   ```

If connection fails:
- Double-check SSID and password
- Confirm 2.4GHz network
- Move ESP32 closer to router

### Test Weather API

After WiFi connects, check Serial Monitor for:
```
Weather updated: Clear
API Response: 200
```

If API fails:
- Verify API key is activated (wait 2 hours if new)
- Check city name spelling
- Confirm internet connection

### Test LEDs

- LEDs should light up with current weather effect
- Try pressing button to toggle power
- Check Serial Monitor for effect changes

### Test HomeKit

1. Open Home app on iPhone/iPad
2. Add accessory
3. Scan QR code from Serial Monitor
4. Or manually enter setup code
5. Complete pairing

---

## Troubleshooting

### "WiFi connection failed"
→ Check SSID, password, and 2.4GHz band

### "Weather API error 401"
→ Invalid API key or not activated yet

### "Weather API error 404"
→ City name not found, check spelling

### LEDs not working
→ Verify LED_PIN, power supply, and wiring

### Button not responding
→ Check BUTTON_PIN and physical connection

---

## Security Best Practices

### Protecting Credentials

**Option 1: Use a separate config file (Advanced)**

Create `config.h`:
```cpp
// config.h
#define WIFI_SSID "YourNetwork"
#define WIFI_PASS "YourPassword"
#define API_KEY "YourAPIKey"
#define CITY_NAME "YourCity"
```

Add to `.gitignore`:
```
config.h
```

Include in main file:
```cpp
#include "config.h"
const char* ssid = WIFI_SSID;
// etc.
```

**Option 2: Use environment variables (Very Advanced)**

Requires custom build system with preprocessor defines.

**Option 3: Use WiFiManager library (Future Feature)**

Web-based configuration portal (planned for v2.0).

---

## Next Steps

Once configured:
1. Upload code to ESP32
2. Verify operation via Serial Monitor
3. Pair with HomeKit
4. Test all weather effects
5. Place in enclosure and enjoy!

**Need help?** Open an issue on GitHub with your Serial Monitor output (remove sensitive data first).
