# Contributing to Weather Lamp

Thank you for considering contributing to Weather Lamp! This document provides guidelines and instructions for contributing.

## How to Contribute

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates. When creating a bug report, include:

- **Description**: Clear description of the problem
- **Steps to Reproduce**: Detailed steps to reproduce the issue
- **Expected Behavior**: What you expected to happen
- **Actual Behavior**: What actually happened
- **Hardware**: ESP32 board model, LED count, etc.
- **Software**: Arduino IDE version, library versions
- **Serial Output**: Relevant debug information from Serial Monitor

### Suggesting Enhancements

Enhancement suggestions are welcome! Please provide:

- **Use Case**: Why this feature would be useful
- **Description**: Clear description of the proposed feature
- **Examples**: How it would work in practice
- **Mockups**: Visual mockups if applicable (for UI changes)

### Pull Requests

1. **Fork** the repository
2. **Create a branch** from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**:
   - Follow the coding style (see below)
   - Test thoroughly on actual hardware
   - Update documentation if needed
4. **Commit** with clear messages:
   ```bash
   git commit -m "Add feature: description of feature"
   ```
5. **Push** to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```
6. **Open a Pull Request** with:
   - Clear title and description
   - Reference any related issues
   - Screenshots/videos if applicable
   - Test results

## Development Guidelines

### Code Style

- **Indentation**: 2 spaces (no tabs)
- **Naming**:
  - Variables: `camelCase`
  - Constants: `UPPER_SNAKE_CASE`
  - Functions: `camelCase`
- **Comments**: 
  - Use `//` for single-line comments
  - Add explanatory comments for complex logic
  - Keep comments concise and relevant

### Testing

Before submitting:

- [ ] Code compiles without errors or warnings
- [ ] Tested on actual ESP32 hardware
- [ ] All weather effects still work correctly
- [ ] HomeKit pairing and control functional
- [ ] WiFi connection stable
- [ ] No memory leaks (monitor Serial for crashes)
- [ ] Power consumption acceptable

### Adding New Weather Effects

To add a new weather effect:

1. Create new header file: `effects_youreffect.h`
2. Follow existing effect structure:
   ```cpp
   void renderYourEffect() {
     // Your animation code here
     FastLED.show();
   }
   ```
3. Add to `WeatherLamp.ino`:
   - Include header at top
   - Add case to `renderWeather()` switch
   - Map weather condition to your effect
4. Update README.md with new effect description

### Weather API Integration

When modifying API code:

- Maintain OpenWeatherMap free tier compatibility
- Handle API errors gracefully
- Respect rate limits
- Add appropriate debug output
- Test with various weather conditions

### HomeKit Integration

When changing HomeKit features:

- Test pairing process thoroughly
- Verify all accessories work in Home app
- Test automations and scenes
- Document any new HomeKit services
- Maintain backward compatibility

## Project Structure

```
weather-lamp/
├── WeatherLamp.ino          # Main sketch - setup(), loop(), WiFi, API
├── effects_*.h              # Weather effect animations
├── README.md                # User documentation
├── CONTRIBUTING.md          # This file
├── LICENSE                  # MIT License
└── .gitignore              # Git ignore rules
```

## Communication

- **Issues**: For bugs, questions, and feature requests
- **Discussions**: For general questions and ideas
- **Pull Requests**: For code contributions

## Code of Conduct

### Our Standards

- Be respectful and inclusive
- Welcome newcomers and learners
- Accept constructive criticism gracefully
- Focus on what's best for the community
- Show empathy towards others

### Unacceptable Behavior

- Harassment or discriminatory language
- Trolling or insulting comments
- Publishing others' private information
- Other unprofessional conduct

## Recognition

Contributors will be:
- Listed in project credits
- Mentioned in release notes
- Thanked in commit messages

## Questions?

Feel free to open an issue with the "question" label, or reach out through GitHub Discussions.

---

Thank you for contributing to Weather Lamp! 🌦️💡
