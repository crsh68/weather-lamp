# Weather Effects Documentation

This document describes each weather effect in detail, including the animation logic and how to customize them.

## Effect Files Overview

Each weather effect is contained in its own header file for modularity and easy customization.

### File Structure

```cpp
void renderEffectName() {
  // Animation logic
  FastLED.show();
}
```

All effects are called from `WeatherLamp.ino` in the `renderWeather()` function.

---

## 1. Sunny Effect (`effects_sunny.h`)

**Weather Conditions**: Clear, Clear Sky  
**Description**: Warm sunrise/sunset gradient animation with rotating colors

### Animation Details
- Uses 3 color phases that smoothly transition
- **Phase 1**: Orange-red sunrise
- **Phase 2**: Bright yellow midday
- **Phase 3**: Purple-pink sunset
- Smooth breathing effect
- Complete cycle: ~6 seconds
- No discrete steps, continuous gradient

### Color Palette
```cpp
CHSV(10, 255, brightness)   // Red-orange
CHSV(40, 255, brightness)   // Yellow-orange
CHSV(25, 255, brightness)   // Orange
CHSV(290, 180, brightness)  // Purple-pink
```

### Customization Ideas
- Add more phases (blue sky, golden hour)
- Speed up/slow down transitions
- Add sparkle effect for sun glints
- Create asymmetric patterns

---

## 2. Cloudy Effect (`effects_clouds.h`)

**Weather Conditions**: Clouds, Few Clouds, Scattered Clouds, Broken Clouds, Overcast  
**Description**: Gentle grey clouds moving across the strip

### Animation Details
- Uses sine wave pattern for smooth movement
- Grey color palette (low saturation)
- Wave movement creates cloud-like appearance
- Slow, peaceful animation
- Multiple wave frequencies for depth

### Parameters
- **Speed**: 0.05 (slow drift)
- **Wave frequency**: LED position / 3.0
- **Brightness**: 60-180 range

### Customization Ideas
- Add slight color variation (bluish or purplish tint)
- Multiple wave layers for 3D effect
- Random darker "shadows" in clouds
- Faster movement for windy conditions

---

## 3. Rain Effect (`effects_rain.h`)

**Weather Conditions**: Rain, Light Rain, Moderate Rain, Heavy Rain, Drizzle  
**Description**: Blue raindrops falling down the LED strip

### Animation Details
- Multiple raindrops at different positions
- Each drop has velocity and trail
- Blue color palette
- Drops "fall" by moving position each frame
- New drops spawn at random intervals

### Raindrop Structure
```cpp
struct {
  int position;
  int velocity;
  CRGB color;
}
```

### Customization Ideas
- Adjust drop density for light/heavy rain
- Add splash effect at bottom
- Vary drop sizes (brightness)
- Add thunder flashes for storms
- Create diagonal rain (wind effect)

---

## 4. Thunder Effect (`effects_thunder.h`)

**Weather Conditions**: Thunderstorm, Storm, Heavy Thunderstorm  
**Description**: Dark storm clouds with bright lightning flashes

### Animation Details
- Base layer: Dark grey/blue storm clouds
- Random lightning strikes
- Lightning has build-up, peak, and fade
- Multi-branch lightning (multiple LEDs)
- Thunder intervals: 3-10 seconds between strikes

### Lightning Sequence
1. **Build-up**: Gradual brightening (100ms)
2. **Flash**: Instant bright white (50ms)
3. **Fade**: Quick decay (200ms)
4. **Afterglow**: Dim glow (500ms)

### Customization Ideas
- Add purple tint to lightning
- Multiple simultaneous strikes
- Chain lightning (LED to LED)
- Sync with audio output
- Different intensities for different storm types

---

## 5. Snow Effect (`effects_snow.h`)

**Weather Conditions**: Snow, Light Snow, Heavy Snow, Sleet  
**Description**: White snowflakes gently falling

### Animation Details
- Multiple snowflakes at different heights
- Slow, gentle falling motion
- White/pale blue colors
- Variable brightness for depth perception
- Occasional "twinkle" for ice crystals

### Snowflake Parameters
```cpp
position      // Current LED position
velocity      // Fall speed (slow)
brightness    // Size/distance indicator
sparkle       // Random twinkle effect
```

### Customization Ideas
- Add swirling motion (side-to-side)
- Accumulation effect at bottom
- Blue tint for blizzard conditions
- Vary fall speed for wind
- Add ice crystal sparkles

---

## 6. Fog Effect (`effects_fog.h`)

**Weather Conditions**: Fog, Mist, Haze  
**Description**: Misty grey gradient waves

### Animation Details
- Smooth gradient waves moving slowly
- Low saturation grey tones
- Multiple wave layers
- Creates depth and mystery
- Very slow movement

### Wave Parameters
- **Frequency**: Low (long wavelengths)
- **Speed**: Very slow (0.02)
- **Brightness**: 40-120 range
- **Colors**: Grey, pale blue, white

### Customization Ideas
- Add color tint (yellow for smog, blue for marine fog)
- Vary density (brightness range)
- Add occasional clearer spots
- Pulsing effect for density changes
- Combine with rain for foggy rain

---

## 7. Wind Effect (`effects_wind.h`)

**Weather Conditions**: Windy, Dust, Sand, Ash, Squall, Tornado  
**Description**: Fast-moving white/cyan streaks

### Animation Details
- Rapid horizontal movement
- Sharp, defined streaks
- White and cyan colors
- Variable speeds
- Creates sense of motion and energy

### Streak Properties
```cpp
length        // Number of LEDs
speed         // Movement rate (fast)
brightness    // Intensity
color         // White to cyan gradient
```

### Customization Ideas
- Brown tint for dust storms
- Orange for sandstorms
- Grey for ash
- Vary speed based on wind intensity
- Add directional indicators
- Swirling patterns for tornadoes

---

## 8. Amber Alert Effect (`effects_amber.h`)

**Weather Conditions**: Smoke, Air Quality Alerts  
**Description**: Solid amber/orange warning color

### Animation Details
- Simple solid color fill
- Warm amber/orange hue
- Optional gentle pulsing
- Attention-grabbing but not harsh

### Color
```cpp
CRGB(255, 100, 0)  // Amber orange
// Or
CHSV(30, 255, brightness)
```

### Customization Ideas
- Add slow pulsing (breathing effect)
- Red tint for severe alerts
- Flashing for emergency conditions
- Gradient between amber and red
- Include UV index warnings

---

## Creating Custom Effects

### Template Structure

```cpp
// effects_youreffect.h

void renderYourEffect() {
  // Clear LEDs (optional)
  FastLED.clear();
  
  // Your animation logic here
  for (int i = 0; i < LED_COUNT; i++) {
    // Calculate color for each LED
    leds[i] = CRGB(r, g, b);
    // or
    leds[i] = CHSV(hue, sat, brightness);
  }
  
  // Update display
  FastLED.show();
  
  // Delay for animation speed
  delay(20);  // 50 FPS
}
```

### Best Practices

1. **Performance**: Keep calculations simple for smooth animation
2. **Brightness**: Respect global brightness setting
3. **Colors**: Use FastLED color functions for smooth gradients
4. **Timing**: Use `millis()` instead of `delay()` for complex timing
5. **Memory**: Avoid dynamic allocation in animation loop
6. **Transitions**: Smooth changes, avoid hard cuts

### Color Helpers

```cpp
// HSV (Hue, Saturation, Value)
CHSV(hue, sat, val)  // hue: 0-255, sat: 0-255, val: 0-255

// RGB (Red, Green, Blue)
CRGB(r, g, b)  // r, g, b: 0-255

// Gradients
fill_gradient_RGB(leds, startPos, startColor, endPos, endColor);

// Blending
blend(color1, color2, amount);  // amount: 0-255
```

### Animation Patterns

**Wave Pattern**:
```cpp
float wave = sin((i + millis() / 100.0) * 0.5);
uint8_t brightness = 128 + 127 * wave;
```

**Particle System**:
```cpp
struct Particle {
  int pos;
  int velocity;
  CRGB color;
};
```

**Noise Pattern**:
```cpp
uint8_t noiseValue = inoise8(i * 50, millis() / 10);
leds[i] = CHSV(noiseValue, 255, brightness);
```

---

## Effect Mapping

Edit `WeatherLamp.ino` to change which weather conditions trigger which effects:

```cpp
void renderWeather() {
  if (weatherType == "Clear") {
    renderSunny();
  } else if (weatherType == "Clouds") {
    renderClouds();
  }
  // Add your mappings here
}
```

### Weather API Conditions

OpenWeatherMap returns these main weather types:
- Clear
- Clouds
- Rain
- Drizzle
- Thunderstorm
- Snow
- Mist
- Smoke
- Haze
- Dust
- Fog
- Sand
- Ash
- Squall
- Tornado

Map them to your effects as desired!

---

## Performance Tips

1. **Limit `FastLED.show()` calls**: Once per frame (20-50ms)
2. **Pre-calculate**: Do math once, not per LED
3. **Use integers**: Faster than floats on ESP32
4. **Brightness scaling**: Use FastLED's built-in brightness
5. **Test with full LED count**: Verify performance at scale

---

## Testing Effects

Use Serial commands to manually trigger effects:

```cpp
// In loop(), add:
if (Serial.available()) {
  char cmd = Serial.read();
  if (cmd == '1') renderSunny();
  if (cmd == '2') renderClouds();
  // etc.
}
```

---

**Ready to create your own effects?** Start with the template and experiment! Share your creations via pull request! 🌦️💡
