# Frequently Asked Questions (FAQ)

## General Questions

### What is Weather Lamp?
Weather Lamp is an ESP32-based smart lamp that displays real-time weather conditions through dynamic LED animations. It integrates with Apple HomeKit for smart home control.

### What can it display?
- ☀️ Sunny weather (warm gradient)
- ☁️ Cloudy conditions (grey clouds)
- 🌧️ Rain (falling blue drops)
- ⛈️ Thunderstorms (lightning flashes)
- ❄️ Snow (white snowflakes)
- 🌫️ Fog (misty waves)
- 💨 Wind (fast streaks)
- 🟠 Amber alerts (solid color)

### How much does it cost to build?
Approximately $30-45 USD for all components (ESP32, LEDs, power supply, etc.). See HARDWARE.md for detailed BOM.

### Do I need programming experience?
Basic Arduino knowledge is helpful, but the code is ready to use. You just need to configure WiFi and API credentials.

---

## Hardware Questions

### Which ESP32 board should I use?
Any ESP32 development board works. Tested on ESP32-WROOM-32. Avoid ESP8266 (not compatible with HomeSpan).

### Can I use a different LED count?
Yes! Change `LED_COUNT` in the code. Adjust power supply accordingly (each LED draws ~60mA max).

### What about WS2811 or SK6812 LEDs?
Yes, compatible. Change `LED_TYPE` in code. Check voltage requirements (some WS2811 strips are 12V).

### Can I use RGB LEDs instead of WS2812B?
No, this project requires individually addressable LEDs (WS2812B, WS2811, SK6812, etc.).

### How much power does it use?
- 24 LEDs: ~1-2W typical, ~8W maximum (full white)
- ESP32: ~0.5-1W
- Total: About 2-3W for normal operation

### Does it get hot?
LEDs generate heat at high brightness. Use aluminum channel for heat dissipation. ESP32 runs warm but safe (~40-50°C).

---

## Software Questions

### Which Arduino IDE version?
Arduino IDE 1.8.13 or newer. Arduino IDE 2.x also works.

### What about PlatformIO?
Not officially supported, but should work. You'll need to configure `platformio.ini` yourself.

### Can I use ESPHome or Tasmota?
No, this is native Arduino code with HomeSpan. Not compatible with ESPHome/Tasmota firmware.

### Do I need to compile anything?
No compilation needed. Just install Arduino IDE, libraries, configure credentials, and upload.

---

## Weather API Questions

### Is OpenWeatherMap free?
Yes! Free tier includes 60 calls/minute and 1,000,000 calls/month. This project uses ~4,320 calls/month.

### How accurate is the weather data?
OpenWeatherMap provides professional-grade data from weather stations and satellites. Updated frequently.

### Can I use a different weather API?
Yes, but requires code modifications. You'd need to change the API endpoint and JSON parsing.

### What if my API key stops working?
- Check if key is activated (new keys take ~2 hours)
- Verify not exceeding rate limits
- Confirm account is active
- Generate new key if needed

### Can I display weather for multiple cities?
Not currently supported. Planned for future version. You'd need to modify code to switch between cities.

---

## HomeKit Questions

### Which devices can control it?
- iPhone, iPad (Home app)
- Apple Watch
- HomePod, HomePod mini
- Apple TV
- Mac (Home app)

### Do I need a HomePod or Apple TV?
No, for local control. Yes, for remote access away from home (acts as Home Hub).

### Can I use Siri?
Yes! "Hey Siri, turn on Weather Lamp" or "Set Weather Lamp to 50%"

### Does it work with Google Home or Alexa?
No, HomeKit only. Adding other platforms requires different code/libraries.

### What HomeKit features work?
- Power on/off
- Brightness (0-100%)
- Scenes and automations
- Siri voice control

### What HomeKit features DON'T work?
- Color selection (lamp shows weather, not custom colors)
- Temperature (not implemented)
- Multiple accessory modes

### Can I create automations?
Yes! Examples:
- Turn on at sunset
- Turn off at bedtime
- Adjust brightness based on time
- Include in scenes

### How do I unpair from HomeKit?
Long-press the physical button during startup (first 30 seconds) to reset HomeKit pairing.

---

## Network Questions

### Does it need internet?
Yes, to fetch weather data. If internet drops, it shows last known weather until reconnected.

### What about WiFi range?
Standard ESP32 WiFi range (~30 meters indoors). Use WiFi extender if needed.

### Can I use 5GHz WiFi?
No, ESP32 only supports 2.4GHz WiFi.

### Does it work on guest networks?
Maybe. Avoid networks with captive portals (login pages). HomeKit requires mDNS/Bonjour.

### Can I use Ethernet?
Not without additional hardware (Ethernet module). WiFi-only in default configuration.

### What ports does it use?
- HTTP: 80 (OpenWeatherMap API)
- HomeKit: 5353 (mDNS), dynamic HAP ports
- No port forwarding needed

---

## Troubleshooting Questions

### LEDs flicker or show wrong colors
- Check ground connection (common ground between ESP32 and power supply)
- Add 300-500Ω resistor on data line
- Add 1000µF capacitor across power supply
- Shorten data wire if too long

### Weather doesn't update
- Check WiFi connection
- Verify API key is valid
- Confirm city name spelling
- Check Serial Monitor for errors

### HomeKit pairing fails
- Ensure iPhone and ESP32 on same network
- Check setup code is correct
- Try resetting HomeKit (long-press button)
- Restart ESP32 and try again

### ESP32 keeps resetting
- Power supply insufficient
- Add capacitor near ESP32
- Check for code crashes in Serial Monitor
- Update to latest libraries

### Button doesn't work
- Verify connection to GPIO 15 and GND
- Test button continuity
- Check Serial Monitor for press events

---

## Customization Questions

### Can I change the colors?
Yes! Edit effect files (`effects_*.h`) to customize color palettes and animations.

### Can I add new weather effects?
Yes! Create new header file, add to switch statement. See CONTRIBUTING.md for guide.

### Can I change animation speed?
Yes, adjust delay values in effect files. Higher delay = slower animation.

### Can I use it as a normal light?
Sort of. HomeKit controls power and brightness, but colors are determined by weather.

### Can I add a web interface?
Not included, but possible to add. Requires additional code for web server.

---

## Project Questions

### Is this open source?
Yes! MIT License. Free to use, modify, and distribute.

### Can I sell lamps with this code?
Yes, under MIT License terms. Attribution appreciated but not required.

### Can I contribute?
Absolutely! See CONTRIBUTING.md for guidelines.

### Where can I get help?
- GitHub Issues for bugs
- GitHub Discussions for questions
- Serial Monitor (115200 baud) for debugging

### What's the roadmap?
See CHANGELOG.md and GitHub Issues for planned features:
- Web configuration portal
- Multiple city support
- Weather forecasts
- Custom colors
- MQTT integration

---

## Safety Questions

### Is it safe to leave on 24/7?
Yes, designed for continuous operation. LEDs and ESP32 stay cool at normal brightness.

### What about fire risk?
Very low when properly assembled:
- Use correct power supply
- Don't exceed LED strip ratings
- Ensure adequate cooling
- Use proper wire gauge

### Can I use it outdoors?
Not without weatherproof enclosure. ESP32 and LEDs are not waterproof.

### Is it safe for children?
Yes, low voltage (5V). Keep small parts away from young children during assembly.

---

## Still Have Questions?

- Check the [README.md](README.md) for setup guide
- See [HARDWARE.md](HARDWARE.md) for wiring help
- Read [CONFIGURATION.md](CONFIGURATION.md) for settings
- Open an issue on GitHub
- Enable Serial Monitor (115200 baud) for debug info

---

**Weather Lamp** - Making weather visible! 🌦️💡
