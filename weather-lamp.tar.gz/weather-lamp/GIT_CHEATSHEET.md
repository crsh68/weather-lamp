# Git Workflow Cheat Sheet

Quick reference for common Git operations when working with Weather Lamp repository.

## Initial Setup

### First Time Git Configuration
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### Initialize Repository
```bash
cd weather-lamp
git init
git branch -M main
```

### Add Remote
```bash
git remote add origin https://github.com/YOUR_USERNAME/weather-lamp.git
```

---

## Daily Workflow

### Check Status
```bash
git status                    # See what's changed
git diff                      # See detailed changes
git diff filename.ino         # Changes in specific file
```

### Stage Changes
```bash
git add filename.ino          # Add specific file
git add *.h                   # Add all header files
git add .                     # Add all changes
```

### Commit Changes
```bash
git commit -m "Fixed WiFi reconnection issue"
git commit -m "Added new rainbow effect"
git commit -m "Updated README with photos"
```

### Push to GitHub
```bash
git push                      # Push committed changes
git push origin main          # Explicit push to main branch
```

### Pull Latest Changes
```bash
git pull                      # Fetch and merge latest changes
git pull origin main          # Explicit pull from main
```

---

## Branching

### Create New Branch
```bash
git checkout -b feature/web-config        # Create and switch to new branch
git checkout -b bugfix/homekit-pairing    # Bug fix branch
git checkout -b develop                   # Development branch
```

### Switch Branches
```bash
git checkout main             # Switch to main branch
git checkout develop          # Switch to develop branch
```

### List Branches
```bash
git branch                    # Local branches
git branch -a                 # All branches (including remote)
```

### Delete Branch
```bash
git branch -d feature/old-feature         # Delete local branch
git push origin --delete feature/old-feature  # Delete remote branch
```

---

## Undoing Changes

### Discard Uncommitted Changes
```bash
git checkout -- filename.ino  # Discard changes to file
git checkout -- .             # Discard all changes
git restore filename.ino      # Alternative (Git 2.23+)
```

### Unstage Files
```bash
git reset HEAD filename.ino   # Unstage specific file
git reset HEAD .              # Unstage all files
git restore --staged file.ino # Alternative (Git 2.23+)
```

### Undo Last Commit (Keep Changes)
```bash
git reset --soft HEAD~1       # Undo commit, keep changes staged
git reset HEAD~1              # Undo commit, unstage changes
```

### Undo Last Commit (Discard Changes)
```bash
git reset --hard HEAD~1       # ⚠️ DANGEROUS: Permanently deletes changes
```

### Amend Last Commit
```bash
git commit --amend            # Edit last commit message
git commit --amend -m "New message"
git add forgotten_file.h
git commit --amend --no-edit  # Add file to last commit
```

---

## Viewing History

### View Commit Log
```bash
git log                       # Full log
git log --oneline             # Compact log
git log --oneline --graph     # Visual branch graph
git log --oneline -n 5        # Last 5 commits
git log --author="YourName"   # Your commits only
```

### View Specific Commit
```bash
git show commit_hash          # Show commit details
git show HEAD                 # Show latest commit
git show HEAD~1               # Show previous commit
```

### View File History
```bash
git log filename.ino          # Commits that changed file
git log -p filename.ino       # Commits with actual changes
```

---

## Merging

### Merge Branch into Current Branch
```bash
git checkout main             # Switch to target branch
git merge feature/new-effect  # Merge feature branch
```

### Resolve Merge Conflicts
```bash
# 1. Edit conflicted files manually
# 2. Mark as resolved:
git add conflicted_file.ino
# 3. Complete merge:
git commit
```

### Abort Merge
```bash
git merge --abort             # Cancel merge and return to pre-merge state
```

---

## Tagging (Releases)

### Create Tag
```bash
git tag v1.0.0                # Lightweight tag
git tag -a v1.0.0 -m "Version 1.0.0 - Initial release"  # Annotated tag
```

### Push Tags
```bash
git push origin v1.0.0        # Push specific tag
git push --tags               # Push all tags
```

### List Tags
```bash
git tag                       # List all tags
git tag -l "v1.*"             # List v1.x tags
```

### Delete Tag
```bash
git tag -d v1.0.0             # Delete local tag
git push origin --delete v1.0.0  # Delete remote tag
```

---

## Stashing (Temporary Save)

### Save Work in Progress
```bash
git stash                     # Save changes temporarily
git stash save "WIP: testing new effect"  # With message
```

### List Stashes
```bash
git stash list                # Show all stashes
```

### Apply Stash
```bash
git stash apply               # Apply latest stash (keep stash)
git stash pop                 # Apply and delete latest stash
git stash apply stash@{1}     # Apply specific stash
```

### Delete Stash
```bash
git stash drop stash@{0}      # Delete specific stash
git stash clear               # Delete all stashes
```

---

## Remote Management

### View Remotes
```bash
git remote -v                 # List remote URLs
```

### Add Remote
```bash
git remote add upstream https://github.com/original/repo.git
```

### Change Remote URL
```bash
git remote set-url origin https://github.com/new/url.git
```

### Remove Remote
```bash
git remote remove upstream
```

### Fetch from Remote
```bash
git fetch origin              # Download remote changes (don't merge)
git fetch --all               # Fetch from all remotes
```

---

## Collaboration

### Clone Repository
```bash
git clone https://github.com/USERNAME/weather-lamp.git
cd weather-lamp
```

### Fork Workflow
```bash
# 1. Fork on GitHub
# 2. Clone your fork
git clone https://github.com/YOUR_USERNAME/weather-lamp.git
cd weather-lamp

# 3. Add upstream remote
git remote add upstream https://github.com/ORIGINAL_OWNER/weather-lamp.git

# 4. Create feature branch
git checkout -b feature/my-improvement

# 5. Make changes, commit, push
git push origin feature/my-improvement

# 6. Create Pull Request on GitHub
```

### Sync with Upstream
```bash
git fetch upstream            # Fetch upstream changes
git checkout main             # Switch to main branch
git merge upstream/main       # Merge upstream into your main
git push origin main          # Push to your fork
```

---

## Cleaning Up

### Remove Untracked Files
```bash
git clean -n                  # Dry run (see what would be deleted)
git clean -f                  # Delete untracked files
git clean -fd                 # Delete untracked files and directories
```

### Prune Old Branches
```bash
git fetch -p                  # Prune deleted remote branches
git branch --merged | grep -v "\*" | xargs -n 1 git branch -d  # Delete merged branches
```

---

## Troubleshooting

### Fix "Detached HEAD"
```bash
git checkout main             # Return to main branch
```

### Force Push (Use with Caution!)
```bash
git push --force              # ⚠️ Overwrites remote history
git push --force-with-lease   # Safer: fails if someone else pushed
```

### Recover Deleted Commit
```bash
git reflog                    # Find lost commit hash
git checkout commit_hash      # Check it out
git cherry-pick commit_hash   # Apply to current branch
```

### Fix "Your branch is ahead by X commits"
```bash
git push                      # Push local commits to remote
```

### Fix "Your branch is behind by X commits"
```bash
git pull                      # Pull remote changes
```

### Fix Diverged Branches
```bash
git pull --rebase             # Rebase your changes on top of remote
# or
git pull                      # Merge remote changes
```

---

## GitHub-Specific

### View PR Locally
```bash
git fetch origin pull/123/head:pr-123
git checkout pr-123
```

### Create Release
```bash
git tag -a v1.1.0 -m "Release v1.1.0"
git push origin v1.1.0
# Then create release on GitHub from tag
```

---

## Commit Message Best Practices

### Format
```
<type>: <short summary>

<detailed description>

<footer>
```

### Types
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation only
- `style:` Code formatting (no logic change)
- `refactor:` Code restructuring
- `test:` Adding tests
- `chore:` Maintenance tasks

### Examples
```bash
git commit -m "feat: Add web configuration portal"
git commit -m "fix: Resolve WiFi reconnection bug"
git commit -m "docs: Update README with installation photos"
git commit -m "refactor: Simplify weather effect rendering"
```

---

## Useful Aliases

Add to `~/.gitconfig`:

```ini
[alias]
    st = status
    co = checkout
    br = branch
    ci = commit
    unstage = reset HEAD --
    last = log -1 HEAD
    visual = log --oneline --graph --decorate --all
    amend = commit --amend --no-edit
```

Usage:
```bash
git st                        # Instead of git status
git co main                   # Instead of git checkout main
git visual                    # Pretty branch visualization
```

---

## Quick Reference Card

| Task | Command |
|------|---------|
| Initialize repo | `git init` |
| Clone repo | `git clone <url>` |
| Check status | `git status` |
| Stage file | `git add <file>` |
| Stage all | `git add .` |
| Commit | `git commit -m "message"` |
| Push | `git push` |
| Pull | `git pull` |
| Create branch | `git checkout -b <name>` |
| Switch branch | `git checkout <name>` |
| Merge branch | `git merge <name>` |
| View log | `git log --oneline` |
| Undo changes | `git checkout -- <file>` |
| Undo commit | `git reset HEAD~1` |
| Stash changes | `git stash` |
| Apply stash | `git stash pop` |

---

## Need More Help?

- Official Git docs: https://git-scm.com/doc
- GitHub guides: https://guides.github.com/
- Interactive tutorial: https://learngitbranching.js.org/
- Cheat sheet: https://education.github.com/git-cheat-sheet-education.pdf

---

**Remember**: Git has a learning curve, but these commands cover 95% of daily usage!

Practice with your Weather Lamp project and you'll be a Git pro in no time! 🚀
