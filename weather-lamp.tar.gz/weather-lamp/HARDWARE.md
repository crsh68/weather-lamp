# Hardware Setup Guide

## Components Required

### Core Components
- **ESP32 Development Board** (ESP32-WROOM-32 or similar)
- **WS2812B LED Strip** (24 LEDs recommended, adjustable)
- **Push Button** (momentary, normally open)
- **Power Supply** (5V, minimum 2A for 24 LEDs)
- **Micro USB Cable** (for programming ESP32)

### Optional Components
- **Enclosure/Housing** (3D printed or purchased)
- **Diffuser Material** (for LED light diffusion)
- **Heat Shrink Tubing** (for wire connections)
- **JST Connectors** (for modular connections)

## Wiring Diagram

```
                    ┌─────────────────┐
                    │     ESP32       │
                    │   Dev Board     │
                    │                 │
   ┌────────────────┤ GPIO 5          │
   │                │                 │
   │   ┌────────────┤ GPIO 15         │
   │   │            │                 │
   │   │        GND ├────────┬────────┤
   │   │            │        │        │
   │   │        5V  ├────────┼────────┤
   │   │            │        │        │
   │   │            └────────┼────────┘
   │   │                     │
   │   │    ┌────────┐       │
   │   │    │        │       │
   │   └────┤ Button │───────┘
   │        │        │
   │        └────────┘
   │
   │        ┌────────────────────┐
   │        │   WS2812B LED      │
   │        │   Strip (24 LEDs)  │
   │        │                    │
   └────────┤ DIN (Data In)      │
            │                    │
        ┌───┤ 5V                 │
        │   │                    │
        └───┤ GND                │
            │                    │
            └────────────────────┘
```

## Detailed Connection Instructions

### LED Strip Connection

1. **Data Line (DIN)**
   - Connect LED strip **DIN** to ESP32 **GPIO 5**
   - Use a 300-500Ω resistor in series (recommended, prevents data corruption)
   - Keep wire length under 1 meter for reliable signal

2. **Power (+5V)**
   - Connect LED strip **5V** to external power supply **+5V**
   - **DO NOT** power LEDs from ESP32's 5V pin (insufficient current)
   - For 24 LEDs at full brightness: ~1.5A required
   - Use adequate gauge wire (20 AWG or thicker)

3. **Ground (GND)**
   - Connect LED strip **GND** to power supply **GND**
   - **IMPORTANT**: Also connect power supply GND to ESP32 GND (common ground)
   - Poor grounding causes flickering and data errors

### Button Connection

1. **One Side**: Connect to ESP32 **GPIO 15**
2. **Other Side**: Connect to ESP32 **GND**
3. **Note**: Internal pull-up resistor is used (no external resistor needed)

### Power Supply Connection

1. **ESP32 Power**
   - During development: Power via USB cable
   - Production: Power from 5V power supply via VIN pin or USB

2. **LED Power**
   - Always use external power supply for LEDs
   - Recommended: 5V, 3A power supply for safety margin
   - Each LED draws ~60mA at full white brightness
   - 24 LEDs × 60mA = 1.44A (add 20% margin = ~1.7A minimum)

## Power Consumption

### Current Draw Estimates

| LED Count | Max Current (Full White) | Recommended PSU |
|-----------|-------------------------|-----------------|
| 24 LEDs   | ~1.5A                   | 5V 2A           |
| 50 LEDs   | ~3.0A                   | 5V 4A           |
| 100 LEDs  | ~6.0A                   | 5V 8A           |

### Notes
- Actual consumption varies with colors and brightness
- Weather effects rarely use full white at max brightness
- Average consumption: 30-50% of maximum
- ESP32 adds ~200-500mA

## PCB Layout (Optional)

For permanent installation, consider designing a custom PCB:

```
┌──────────────────────────────────┐
│                                  │
│  ┌────────┐         ┌─────────┐ │
│  │ ESP32  │         │ Button  │ │
│  │ Module │         │         │ │
│  └────────┘         └─────────┘ │
│                                  │
│  LED Strip          Power Input  │
│  Connector          Connector    │
│  ┌──────┐           ┌──────────┐│
│  │ 3Pin │           │ Screw    ││
│  │ JST  │           │ Terminal ││
│  └──────┘           └──────────┘│
│                                  │
└──────────────────────────────────┘
```

## Assembly Tips

### 1. Test First
- Connect everything on breadboard first
- Upload code and verify functionality
- Test each weather effect
- Check HomeKit pairing

### 2. Secure Connections
- Solder all connections (no loose wires)
- Use heat shrink tubing for insulation
- Label wires for troubleshooting
- Test continuity with multimeter

### 3. LED Strip Mounting
- Use aluminum channel for rigidity
- Add diffuser material for smooth light
- Ensure good thermal contact (LEDs generate heat)
- Secure strip to prevent movement

### 4. Enclosure Design
- Ventilation holes for ESP32 and LEDs
- Easy access to button
- Removable panel for USB access
- Cable management for clean look

## Troubleshooting

### LEDs Not Lighting
- Check power supply voltage (should be 4.8-5.2V)
- Verify data line connection to GPIO 5
- Confirm common ground between ESP32 and power supply
- Test with FastLED example sketches

### Flickering LEDs
- Poor ground connection (most common)
- Insufficient power supply capacity
- Data line too long or not shielded
- Add 300-500Ω resistor on data line
- Add 1000µF capacitor across power supply

### Button Not Working
- Check connection to GPIO 15 and GND
- Verify button is normally open (NO)
- Test button continuity with multimeter
- Check serial output for button press events

### ESP32 Resetting
- Power supply insufficient
- Voltage drop during LED current surge
- Add bulk capacitor (1000µF+) near ESP32
- Use separate power source for ESP32

## Safety Warnings

⚠️ **Important Safety Information**

- Never exceed LED strip's voltage rating (5V for WS2812B)
- Use proper gauge wire for current requirements
- Ensure adequate cooling for LEDs and power supply
- Don't power LEDs from ESP32's onboard regulator
- Double-check polarity before connecting power
- Use fuses for overcurrent protection
- Keep water away from electronics

## Recommended Tools

- Soldering iron and solder
- Wire strippers
- Multimeter
- Heat gun (for heat shrink)
- Screwdrivers
- Hot glue gun (optional, for strain relief)

## Bill of Materials (BOM)

| Component | Qty | Approx. Cost |
|-----------|-----|--------------|
| ESP32 Dev Board | 1 | $8-15 |
| WS2812B LED Strip (24 LEDs) | 1m | $10-15 |
| Push Button | 1 | $0.50 |
| 5V 2A Power Supply | 1 | $5-10 |
| Resistors, wire, etc. | - | $5 |
| **Total** | | **~$30-45** |

## Next Steps

After assembly:
1. Upload firmware (see README.md)
2. Configure WiFi and API keys
3. Test all weather effects
4. Pair with HomeKit
5. Mount in final enclosure
6. Enjoy your Weather Lamp! 🌦️💡
