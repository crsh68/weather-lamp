# Security and Privacy Policy

## Data Collection

### What Data Does Weather Lamp Collect?

**The Weather Lamp does NOT collect or store any personal data.** All operations are local.

### Data Used by the Device

1. **WiFi Credentials** (stored locally on ESP32)
   - SSID and password
   - Never transmitted anywhere except to your router
   - Stored in ESP32 flash memory

2. **OpenWeatherMap API Key** (stored locally on ESP32)
   - Used only to fetch weather data
   - Sent only to OpenWeatherMap API servers
   - Never shared with third parties

3. **Location/City Name** (stored locally on ESP32)
   - Used to query weather for your area
   - Sent only to OpenWeatherMap API
   - No GPS or precise location tracking

4. **HomeKit Pairing Data** (stored locally on ESP32)
   - Encrypted credentials for HomeKit communication
   - Managed by HomeSpan library
   - Never leaves your local network

### Third-Party Services

**OpenWeatherMap API**
- Privacy Policy: https://openweathermap.org/privacy-policy
- Data sent: City name, API key
- Data received: Weather conditions
- No personal information shared

**Apple HomeKit**
- Privacy Policy: https://www.apple.com/legal/privacy/
- End-to-end encrypted communication
- Local network communication (no cloud required)
- No data shared with Anthropic or this project

---

## Security Best Practices

### Protecting Your Credentials

**WiFi Password**
- Never commit code with real passwords to public repositories
- Use `.gitignore` to exclude config files
- Consider using separate IoT network for smart devices

**API Key**
- Keep your API key private
- Regenerate if accidentally exposed
- Free tier limits exposure risk
- OpenWeatherMap allows key rotation

**HomeKit Setup Code**
- Change default setup code if desired
- Store securely (needed for re-pairing)
- Reset if device is sold/given away

### Network Security

**WiFi Recommendations**
- Use WPA2 or WPA3 encryption
- Strong password for WiFi network
- Consider separate IoT VLAN
- Disable WPS if possible

**HomeKit Security**
- HomeKit uses encrypted communication
- No cloud account required
- Local authentication only
- Use strong Apple ID password

**Firewall Considerations**
- Weather Lamp only needs outbound HTTP (port 80)
- HomeKit uses mDNS (port 5353) locally
- No inbound ports need to be opened
- Block if you don't need external weather updates

---

## Code Security

### No Backdoors
- Open source code (MIT License)
- All code is visible and auditable
- No hidden functionality
- No telemetry or analytics

### Dependencies
All libraries are from trusted sources:
- **FastLED**: LED control, widely used
- **HomeSpan**: Apple's HomeKit protocol
- **ArduinoJson**: JSON parsing
- **HTTPClient**: ESP32 core library

Review library source code if concerned.

### Secure Coding Practices
- No dynamic memory allocation in critical paths
- Input validation on weather API responses
- Safe string handling
- No shell command execution
- No file system access beyond configuration

---

## Physical Security

### Device Access
- ESP32 has no physical security chip
- Anyone with physical access can:
  - Read flash memory (including WiFi password)
  - Modify code
  - Extract credentials

**Recommendations**:
- Place device in secure location
- Use secure enclosure
- Consider device security for sensitive environments

### USB Access
- USB port provides full firmware access
- Can be used to extract or modify code
- Consider disabling USB after initial setup (requires hardware modification)

---

## Privacy Considerations

### No Analytics
- No usage tracking
- No crash reporting
- No telemetry
- No phone home functionality

### No Cloud Services
- All processing is local
- No cloud accounts required (except OpenWeatherMap API)
- HomeKit works locally (internet not required for control)
- Weather updates are the only external communication

### Local Control
- Works without internet (last known weather)
- HomeKit control is local
- No remote access unless you configure Apple Home Hub

---

## Incident Response

### If Your API Key is Compromised
1. Log into OpenWeatherMap account
2. Navigate to API Keys
3. Delete compromised key
4. Generate new key
5. Update Weather Lamp code with new key
6. Re-upload firmware

### If Your WiFi Password is Exposed
1. Change WiFi password on router
2. Update all devices (including Weather Lamp)
3. Re-upload firmware with new credentials

### If Device is Lost/Stolen
1. Remove from HomeKit (Home app)
2. Change WiFi password (prevent network access)
3. Regenerate API key (if concerned)

### If You Want to Sell/Give Away Device
1. Long-press button during startup (reset HomeKit pairing)
2. Flash blank firmware (or factory reset ESP32)
3. Physically verify LED behavior
4. Provide generic code without your credentials

---

## Compliance

### GDPR (EU Users)
- No personal data collected
- No user tracking
- No cookies or web analytics
- Local operation only

### CCPA (California Users)
- No personal information sold
- No data sharing with third parties
- No analytics or tracking

### Children's Privacy
- Device does not target children
- No age-restricted features
- No data collection
- Safe for use by families

---

## Vulnerability Reporting

### How to Report Security Issues

**Please do NOT open public GitHub issues for security vulnerabilities.**

Instead:
1. Email: [your-email@example.com]
2. Subject: "Weather Lamp Security Issue"
3. Include:
   - Description of vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

### Response Timeline
- **24 hours**: Acknowledgment of report
- **7 days**: Initial assessment
- **30 days**: Fix and disclosure (if applicable)

### Responsible Disclosure
We follow responsible disclosure practices:
- Reporter credited (if desired)
- Public disclosure after fix is available
- Security advisory published on GitHub

---

## Security Updates

### How to Stay Updated
- Watch GitHub repository for releases
- Check CHANGELOG.md for security fixes
- Subscribe to GitHub notifications

### Update Process
1. Backup your configuration (credentials)
2. Download latest release
3. Update code with your credentials
4. Re-upload firmware
5. Test functionality

---

## Encryption

### At Rest
- WiFi password: Plain text in ESP32 flash
- API key: Plain text in ESP32 flash
- HomeKit credentials: Encrypted by HomeSpan

**Note**: ESP32 flash can be encrypted (advanced feature, not enabled by default)

### In Transit
- WiFi: WPA2/WPA3 encryption
- HomeKit: TLS/encrypted HAP protocol
- Weather API: **HTTP (not HTTPS)** - API key visible in transit on local network

**Future Enhancement**: Add HTTPS support for weather API

---

## Audit Information

### Last Security Review
- Date: 2025-02-16
- Reviewer: Project maintainers
- Findings: No critical issues

### Known Limitations
1. API key stored in plain text
2. Weather API uses HTTP (not HTTPS)
3. No ESP32 flash encryption
4. Physical access = full control

These are acceptable for home use but consider for sensitive environments.

---

## Best Practices Summary

✅ **Do:**
- Change default HomeKit setup code
- Use strong WiFi password
- Keep API key private
- Place device in secure location
- Update firmware regularly

❌ **Don't:**
- Commit credentials to public repos
- Share API key publicly
- Use on untrusted networks
- Leave USB port accessible in public spaces
- Ignore security updates

---

## Questions?

For security questions or concerns:
- Email: [your-email@example.com]
- GitHub Issues: For non-security bugs
- Discussions: For general questions

**Remember**: This is a hobby project for home use. For enterprise or critical applications, additional security measures are recommended.

---

**Security is everyone's responsibility. Report issues responsibly.** 🔒
